#!/bin/sh

. ./tools.sh

check_security
