#!/bin/sh

BuildType=wifi

if ! . ./tools.sh; then exit 1; fi

install

deactivate
